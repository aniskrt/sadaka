
// This file is kept for backward compatibility
// It re-exports all APIs from the new modular structure
export * from './api';
